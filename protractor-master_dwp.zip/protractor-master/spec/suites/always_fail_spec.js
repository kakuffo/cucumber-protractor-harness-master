describe('This test suite', function() {
  it('should never be ran through the --suite option', function() {
    expect(true).toBe(false);
  });
});
