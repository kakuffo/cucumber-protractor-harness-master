module.exports = {
  setup: function() {
    protractor.__BASIC_PLUGIN_RAN = true;
  }
};
