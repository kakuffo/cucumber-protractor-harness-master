import {Component} from 'angular2/core';

@Component({
  templateUrl: 'app/home/home-component.html'
})
export class HomeComponent {
  
}
